# coding: UTF-8
import torch
import torch.nn as nn
# from pytorch_pretrained_bert import BertModel, BertTokenizer
from pytorch_pretrained import BertModel

from transformers import  BertTokenizer

class Config(object):


    def __init__(self, dataset):
        self.model_name = 'bert'
        self.train_path = dataset + '/train_ltp_only_multi_noun_sel10_Leven.MASK_1000.txt'                                
        self.dev_path = dataset + '/ltp_simplify_ner_dev_MASK_j.txt'                                    
        self.test_path = dataset + '/part_test/ltp_simplify_ner_test_MASK_data_size_02.txt'                                 # 
        self.class_list = [x.strip() for x in open(
            dataset + '/class.txt').readlines()]                                # 
        self.save_path = dataset + '/saved_dict/' + self.model_name + 'ckpt.context.all.allpara.02'        # 
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')   # 

        self.require_improvement = 3000                                 # 
        self.num_classes = len(self.class_list)                         # 
        self.num_epochs = 4                                             # 
        self.batch_size = 64                                           # 
        self.pad_size = 32                                              # 
        self.learning_rate = 5e-6                                       #
        self.bert_path_share = 'BERT'
        self.tokenizer_share = BertTokenizer.from_pretrained(self.bert_path_share)
        self.hidden_size = 768


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        self.bert_share = BertModel.from_pretrained(config.bert_path_share)
        # self.bert_context = BertModel.from_pretrained(config.bert_path_context)
        self.dropout_entity = nn.Dropout(0.5)
        self.dropout_context = nn.Dropout(0.5)
        for param in self.bert_share.parameters():
            param.requires_grad = True
        # for param in self.bert_context.parameters():
        #     param.requires_grad = True
        self.fc = nn.Linear(config.hidden_size * 2, config.num_classes)
        self.fc_entity = nn.Linear(config.hidden_size, config.num_classes)
        self.fc_context = nn.Linear(config.hidden_size, config.num_classes)

    def forward(self, train_entity, train_context):
        entity_content = train_entity[0]  # 
        entity_mask = train_entity[2]  # 
        _, entity_pooled = self.bert_share(entity_content, attention_mask=entity_mask, output_all_encoded_layers=False)

        entity_pooled = self.dropout_entity(entity_pooled)

        out_entity = self.fc_entity(entity_pooled)

        context_content = train_context[0]  #
        context_mask = train_context[2]  # 
        maskpos = train_context[3]
        context_hidden, context_pooled = self.bert_share(context_content, attention_mask=context_mask, output_all_encoded_layers=False)

        h_output = context_hidden
        if torch.cuda.is_available():
            pooled_output_context = torch.Tensor(h_output.shape[0], h_output.shape[-1]).cuda()
        else:
            pooled_output_context = torch.Tensor(h_output.shape[0], h_output.shape[-1])
        for i in range(len(context_hidden)):

            pooled_output_context[i] = h_output[i].index_select(0,maskpos[i])
        #

        pooled_output_context = self.dropout_context(pooled_output_context)

        out_context = self.fc_context(pooled_output_context)

        pooled_output = torch.cat([entity_pooled, pooled_output_context], dim=-1)

        out = self.fc(pooled_output)
        return out, out_entity, out_context
